# Biomass_validationKNN

Validation module for LandR Biomass predictions of forest succession. Based on Canadian Forest Service KNN maps.
This module is by no means the only way to validate LandR Biomass predictions, but presents a way of doing so using publicly available data.


